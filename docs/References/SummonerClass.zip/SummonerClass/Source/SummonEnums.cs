namespace SummonerClass
{
    // 血脉（流派）
    public enum School : byte
    {
        None = 0,
        Druid,      // 德鲁伊
        Undead,     // 亡灵
        Elemental,  // 元素
        Mechanical, // 机械
        Bug,        // 虫族
        Chaos       // 混沌（影子）
    }

    // 战斗定位
    public enum Archetype : byte
    {
        Warrior = 0, // 战士
        Tank,        // 肉盾
        Ranged       // 远程
    }

    // 召唤状态
    public enum SummonState : byte
    {
        Active = 0,    // 场上
        SpiritRealm,   // 灵魂界（召回）
        Dead           // 死亡
    }
}
