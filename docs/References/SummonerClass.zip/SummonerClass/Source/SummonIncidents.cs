using RimWorld;
using Verse;

namespace SummonerClass
{
    // §14 觉醒事件：小人吸收道具 → 获得自适应栏 + 基础临时召唤技
    public class IncidentWorker_Awakening : IncidentWorker
    {
        protected override bool CanFireNowSub(IncidentParms parms)
        {
            var map = (Map)parms.target;
            return map.mapPawns.FreeColonistsSpawned.Any(p => p.TryGetComp<SummonerComp>() == null);
        }

        protected override bool TryExecuteWorker(IncidentParms parms)
        {
            var map = (Map)parms.target;
            var pawn = map.mapPawns.FreeColonistsSpawned
                .FirstOrDefault(p => p.TryGetComp<SummonerComp>() == null);
            if (pawn == null) return false;

            var comp = new SummonerComp();
            pawn.AllComps.Add(comp);
            comp.GrantAdaptiveSlot();
            // TODO：授予基础临时召唤技能（灵魂呼唤 Ability）与道具提示
            Messages.Message("灵能觉醒：获得自适应召唤栏位。", pawn, MessageTypeDefOf.PositiveEvent);
            return true;
        }
    }
}
