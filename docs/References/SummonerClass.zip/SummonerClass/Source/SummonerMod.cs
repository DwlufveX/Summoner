using Verse;
using HarmonyLib;

namespace SummonerClass
{
    public class SummonerMod : Mod
    {
        public static SummonerMod Instance;

        public SummonerMod(ModContentPack content) : base(content)
        {
            Instance = this;
            var harmony = new Harmony("com.summonerclass.core");
            harmony.PatchAll();
            Log.Message("[SummonerClass] v0.6 prototype loaded.");
        }
    }
}
