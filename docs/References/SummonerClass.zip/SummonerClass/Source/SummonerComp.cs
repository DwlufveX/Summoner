using System.Collections.Generic;
using Verse;

namespace SummonerClass
{
    public class SchoolProgress : IExposable
    {
        public School school = School.None;
        public int level;
        public int xp;
        public int lineagePoints;
        public bool secondSlotUnlocked;

        public void ExposeData()
        {
            Scribe_Values.Look(ref school, "school", School.None);
            Scribe_Values.Look(ref level, "level", 0);
            Scribe_Values.Look(ref xp, "xp", 0);
            Scribe_Values.Look(ref lineagePoints, "lineagePoints", 0);
            Scribe_Values.Look(ref secondSlotUnlocked, "secondSlotUnlocked", false);
        }
    }

    public class Slot : IExposable
    {
        public int index;
        public bool adaptive = true;              // 自适应栏（契约后固定血脉）
        public School fixedSchool = School.None;  // 契约后固定的血脉
        public Pawn beastRef;                     // 当前契约兽
        public int tier = 1;                      // 栏位阶 1..4
        public int tierLevel = 1;                 // 1..40
        public int tierXp;
        public int tierXpBase = 100;              // 当前阶经验基数（随 Tier 放大）
        public SummonState state = SummonState.Active;

        public void ExposeData()
        {
            Scribe_Values.Look(ref index, "index", 0);
            Scribe_Values.Look(ref adaptive, "adaptive", true);
            Scribe_Values.Look(ref fixedSchool, "fixedSchool", School.None);
            Scribe_References.Look(ref beastRef, "beastRef");
            Scribe_Values.Look(ref tier, "tier", 1);
            Scribe_Values.Look(ref tierLevel, "tierLevel", 1);
            Scribe_Values.Look(ref tierXp, "tierXp", 0);
            Scribe_Values.Look(ref tierXpBase, "tierXpBase", 100);
            Scribe_Values.Look(ref state, "state", SummonState.Active);
        }
    }

    // 挂在召唤师 Pawn 上的核心组件（§3.3）
    public class SummonerComp : ThingComp, IExposable
    {
        public float bionicFeedbackRatio = 0.4f; // §4.5 仿生反馈比例（暂无封顶）
        public List<Slot> slots = new List<Slot>();
        public Dictionary<School, SchoolProgress> schoolProgress = new Dictionary<School, SchoolProgress>();
        public bool hasChaosSlot;                // 混沌栏（影子）

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_Values.Look(ref bionicFeedbackRatio, "bionicFeedbackRatio", 0.4f);
            Scribe_Collections.Look(ref slots, "slots", LookMode.Deep);
            Scribe_Collections.Look(ref schoolProgress, "schoolProgress", LookMode.Value, LookMode.Deep);
            Scribe_Values.Look(ref hasChaosSlot, "hasChaosSlot", false);
            // ChaosComp 作为召唤师身上的独立 ThingComp 单独存档
        }

        public Slot GrantAdaptiveSlot()
        {
            var s = new Slot { index = slots.Count, adaptive = true };
            slots.Add(s);
            return s;
        }

        public Slot GetFreeAdaptiveSlot()
        {
            return slots.Find(s => s.adaptive && s.fixedSchool == School.None);
        }

        public Slot GetRecallableSlot()
        {
            return slots.Find(s => s.beastRef != null && s.state == SummonState.SpiritRealm);
        }

        public SchoolProgress GetOrCreateProgress(School school)
        {
            if (!schoolProgress.TryGetValue(school, out var p))
            {
                p = new SchoolProgress { school = school };
                schoolProgress[school] = p;
            }
            return p;
        }

        // §4.5 重算仿生反馈：召唤师仿生净增益按比例平乘到各契约兽（单向·无封顶）
        public void RecomputeBionicFeedback()
        {
            var summoner = parent as Pawn;
            if (summoner == null) return;
            float bonus = ComputeBionicBonus(summoner);
            foreach (var s in slots)
            {
                if (s.beastRef != null)
                {
                    var b = s.beastRef.TryGetComp<BoundSummonComp>();
                    b?.ApplyBionicFeedback(bonus * bionicFeedbackRatio);
                }
            }
            // 影子（混沌）取更低比例 0.25，避免与每级高反馈叠加过强
            var chaos = summoner.TryGetComp<ChaosComp>();
            if (chaos?.shadow != null)
                chaos.shadow.TryGetComp<BoundSummonComp>()?.ApplyBionicFeedback(bonus * 0.25f);
        }

        // 简化：统计已植入的 bionic 部件数量作为增益代理（正式实现按部件 stat 折算）
        public static float ComputeBionicBonus(Pawn p)
        {
            if (p?.health?.hediffSet == null) return 0f;
            float total = 0f;
            foreach (var h in p.health.hediffSet.hediffs)
            {
                if (h.def?.addedPartProps != null) total += 0.06f; // 每件植入部件 +6% 代理
            }
            return total;
        }
    }
}
