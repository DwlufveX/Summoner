using Verse;

namespace SummonerClass
{
    // §4 升级奖励入口（原型占位，正式实现用自定义 Dialog 从池抽 3）
    public static class SummonerReward
    {
        // §4.4 召唤师 3 选 1
        public static void GrantSummonerChoice(Pawn summoner)
        {
            // TODO(§4.4)：弹出 3 选 1（召唤师属性 / 核心绑定技 / 血脉点数 / 反哺强度）
        }

        // §4.1 每次升级：变异属性 3 选 1（体型&生命/攻击/攻速/护甲/特殊部件）
        public static void GrantBeastMutationChoice(Pawn beast)
        {
            // TODO(§4.1)：弹出变异属性 3 选 1，写入 BoundSummonComp.mutationAttrs（永久保留）
        }
    }
}
