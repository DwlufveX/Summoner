using System;
using System.Reflection;
using HarmonyLib;
using Verse;

namespace SummonerClass
{
    // §17.1 战力计入威胁点：把召唤师/兽有效战力折算进袭击点数
    [HarmonyPatch(typeof(IncidentWorker_Raid), "GenerateParms")]
    public static class Patch_RaidPoints
    {
        public static void Postfix(ref IncidentParms parms)
        {
            int bonus = SummonerBalance.ThreatBonus();
            if (bonus > 0 && parms.points > 0) parms.points += bonus;
        }
    }

    // §4.5 仿生部件变化 → 重算反馈
    [HarmonyPatch(typeof(Pawn_HealthTracker), "AddHediff",
        new Type[] { typeof(Hediff), typeof(BodyPartRecord), typeof(DamageInfo?), typeof(DamageWorker.DamageResult) })]
    public static class Patch_BionicFeedback
    {
        public static void Postfix(Pawn_HealthTracker __instance, Hediff hediff)
        {
            if (hediff?.def?.addedPartProps == null) return; // 仅植入部件触发
            var pawn = __instance.pawn;
            pawn?.TryGetComp<SummonerComp>()?.RecomputeBionicFeedback();
        }
    }
}
