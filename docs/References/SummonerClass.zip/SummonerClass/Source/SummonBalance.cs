using System.Linq;
using Verse;

namespace SummonerClass
{
    // §17 平衡：把召唤师/兽有效战力折算为袭击点数增量
    public static class SummonerBalance
    {
        public static int ThreatBonus()
        {
            if (Find.CurrentMap == null) return 0;
            int total = 0;
            foreach (var pawn in Find.CurrentMap.mapPawns.FreeColonistsSpawned)
            {
                var comp = pawn.TryGetComp<SummonerComp>();
                if (comp == null) continue;
                foreach (var s in comp.slots)
                {
                    if (s.beastRef != null && s.state == SummonState.Active)
                        total += s.tier * 80 + s.tierLevel * 4; // 经验公式，调参见 §17.4
                }
            }
            return total;
        }
    }
}
