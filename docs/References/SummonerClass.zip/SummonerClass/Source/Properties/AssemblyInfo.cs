using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("SummonerClass")]
[assembly: AssemblyVersion("0.6.0.0")]
[assembly: AssemblyInformationalVersion("0.6.0")]
