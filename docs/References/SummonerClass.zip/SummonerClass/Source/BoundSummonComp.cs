using System.Collections.Generic;
using Verse;

namespace SummonerClass
{
    // 挂在契约英雄兽 Pawn 上的组件（§3.3）
    public class BoundSummonComp : ThingComp, IExposable
    {
        public Pawn owner;
        public School school = School.None;
        public int occupySlots = 1;              // 占栏数（Tier）
        public int beastLevel;                   // 进化等级
        public Archetype archetype = Archetype.Warrior;
        public float lockHpPct = 0.15f;          // §2 锁血阈值
        public bool inSpiritRealm;
        public Dictionary<string, float> mutationAttrs = new Dictionary<string, float>();
        public int summonerFeedbackCounter;
        public int recallCdTicks;
        public int feedbackEveryLevels = -1;      // -1=按占栏数(§4.4)；>=1=影子每级反馈

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_References.Look(ref owner, "owner");
            Scribe_Values.Look(ref school, "school", School.None);
            Scribe_Values.Look(ref occupySlots, "occupySlots", 1);
            Scribe_Values.Look(ref beastLevel, "beastLevel", 0);
            Scribe_Values.Look(ref archetype, "archetype", Archetype.Warrior);
            Scribe_Values.Look(ref lockHpPct, "lockHpPct", 0.15f);
            Scribe_Values.Look(ref inSpiritRealm, "inSpiritRealm", false);
            Scribe_Collections.Look(ref mutationAttrs, "mutationAttrs", LookMode.Value, LookMode.Value);
            Scribe_Values.Look(ref summonerFeedbackCounter, "summonerFeedbackCounter", 0);
            Scribe_Values.Look(ref recallCdTicks, "recallCdTicks", 0);
            Scribe_Values.Look(ref feedbackEveryLevels, "feedbackEveryLevels", -1);
        }

        public override void CompTick()
        {
            base.CompTick();
            if (recallCdTicks > 0) recallCdTicks--;
            if (!inSpiritRealm) CheckLockHp();
        }

        // §2 锁血退回：HP≤阈值且处于战斗危险 → 包扎全部伤口并退回灵魂界
        private void CheckLockHp()
        {
            var p = parent as Pawn;
            if (p == null || p.Dead || p.health == null) return;
            if (p.health.summaryHealthPercent > lockHpPct) return;
            if (!IsInDanger(p)) return;

            foreach (var h in p.health.hediffSet.GetHediffs<Hediff_Injury>())
                h.Severity = 0f; // 退回前包扎（治愈）所有外伤
            RetreatToSpiritRealm();
        }

        private bool IsInDanger(Pawn p)
        {
            var m = p.Map;
            if (m == null) return false;
            foreach (var thing in GenRadial.RadialDistinctThingsAround(p.Position, m, 12f, true))
            {
                if (thing is Pawn enemy && enemy.HostileTo(p.Faction)) return true;
            }
            return false;
        }

        public void RetreatToSpiritRealm()
        {
            var p = parent as Pawn;
            inSpiritRealm = true;
            recallCdTicks = 1500; // 25s 撤回冷却
            if (p?.Map != null && p.Spawned) p.DeSpawn();
        }

        public void SummonTo(Pawn master)
        {
            if (!inSpiritRealm) return;
            var m = master.Map;
            if (m == null || recallCdTicks > 0) return;
            var p = parent as Pawn;
            IntVec3 cell = CellFinder.RandomClosewalkableCellNear(master.Position, m, 3, null);
            GenSpawn.Spawn(p, cell, m);
            inSpiritRealm = false;
            var slot = master.TryGetComp<SummonerComp>()?.slots.Find(s => s.beastRef == p);
            if (slot != null) slot.state = SummonState.Active;
        }

        // §4.5 仿生反馈（单向、无封顶）：缓存增益，正式实现映射为临时 Hediff
        public void ApplyBionicFeedback(float value)
        {
            var p = parent as Pawn;
            if (p?.health?.hediffSet == null) return;
            // 原型：此处仅缓存；正式实现应按 value 施加/刷新一个 Hediff_Feedback
            // 注意：不反向反馈召唤师，避免左脚踩右脚
        }

        // §4.4 升级 → 累加反馈计数，触发召唤师 3 选 1（按占栏数 / 影子每级）
        public void OnBeastLevelUp(int levels = 1)
        {
            summonerFeedbackCounter += levels;
            int threshold = feedbackEveryLevels >= 1
                ? feedbackEveryLevels
                : (occupySlots >= 2 ? 2 : 4);
            while (summonerFeedbackCounter >= threshold)
            {
                summonerFeedbackCounter -= threshold;
                if (owner != null) SummonerReward.GrantSummonerChoice(owner);
            }
        }
    }
}
