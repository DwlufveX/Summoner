using System.Collections.Generic;
using Verse;

namespace SummonerClass
{
    // 混沌栏：影子复制（§11）
    public class ChaosComp : ThingComp, IExposable
    {
        public Pawn shadow;                 // 影子契约兽（主人投影）
        public float skillEchoRatio = 0.65f; // 技能复现比例
        public int feedbackEveryLevels = 1;   // 影子每升 1 级触发主人 3 选 1
        public List<string> extraProfessions = new List<string>(); // 影子习得的他职
        public int swapCdTicks = 60000;       // §11 互换位置 CD = 1 天（60000 ticks）
        public int swapCdRemaining;

        public override void CompExposeData()
        {
            base.CompExposeData();
            Scribe_References.Look(ref shadow, "shadow");
            Scribe_Values.Look(ref skillEchoRatio, "skillEchoRatio", 0.65f);
            Scribe_Values.Look(ref feedbackEveryLevels, "feedbackEveryLevels", 1);
            Scribe_Collections.Look(ref extraProfessions, "extraProfessions", LookMode.Value);
            Scribe_Values.Look(ref swapCdTicks, "swapCdTicks", 60000);
            Scribe_Values.Look(ref swapCdRemaining, "swapCdRemaining", 0);
        }

        public override void CompTick()
        {
            base.CompTick();
            if (swapCdRemaining > 0) swapCdRemaining--;
        }

        // §11 互换位置：支持跨地图（主影异图时通过传送交换位置）
        public void SwapWithShadow()
        {
            var master = parent as Pawn;
            if (master == null || shadow == null || swapCdRemaining > 0) return;

            if (master.Spawned && shadow.Spawned && master.Map == shadow.Map)
            {
                // 同图：即时交换位置
                var tmp = master.Position;
                master.Position = shadow.Position;
                shadow.Position = tmp;
            }
            else if (master.Spawned && shadow.Spawned && master.Map != shadow.Map)
            {
                // 跨地图：保留各自在对方地图的“对应位置”，正式实现用地图切换/传送 API
                // 原型占位：标记待传送，真实落地见 §15
                SwapAcrossMaps(master, shadow);
            }

            swapCdRemaining = swapCdTicks; // 进入 1 天 CD
        }

        private void SwapAcrossMaps(Pawn a, Pawn b)
        {
            // TODO(§15)：借助 CameraJumper / 传送门 / MapTransition 把两者送进对方地图的对应位置
        }
    }
}
