using Verse;

namespace SummonerClass
{
    // 灵魂呼唤：把灵魂界的契约兽召到主人附近（§2）
    public class Ability_Summon : Ability
    {
        public Ability_Summon(Pawn pawn, AbilityDef def) : base(pawn, def) { }

        public override bool CanCast => base.CanCast && pawn.TryGetComp<SummonerComp>()?.GetRecallableSlot() != null;

        public override void Cast(LocalTargetInfo target)
        {
            base.Cast(target);
            var comp = pawn.TryGetComp<SummonerComp>();
            comp?.GetRecallableSlot()?.beastRef?.TryGetComp<BoundSummonComp>()?.SummonTo(pawn);
        }
    }

    // 召回：把场上契约兽退回灵魂界（§2）
    public class Ability_Recall : Ability
    {
        public Ability_Recall(Pawn pawn, AbilityDef def) : base(pawn, def) { }

        public override void Cast(LocalTargetInfo target)
        {
            base.Cast(target);
            (target.Thing as Pawn)?.TryGetComp<BoundSummonComp>()?.RetreatToSpiritRealm();
        }
    }

    // 灵质复活：扣灵质 → 复刻 BoundSummonComp（§2）
    public class Ability_Revive : Ability
    {
        public Ability_Revive(Pawn pawn, AbilityDef def) : base(pawn, def) { }

        public override void Cast(LocalTargetInfo target)
        {
            base.Cast(target);
            // TODO(§2)：扣除 ThingDef 灵质后调用 ResurrectionUtility.Resurrect 并恢复 BoundSummonComp 关联
        }
    }

    // 互换位置（混沌·影子）：CD=1天，支持跨地图（§11）
    public class Ability_Swap : Ability
    {
        public Ability_Swap(Pawn pawn, AbilityDef def) : base(pawn, def) { }

        public override void Cast(LocalTargetInfo target)
        {
            base.Cast(target);
            pawn.TryGetComp<ChaosComp>()?.SwapWithShadow();
        }
    }
}
